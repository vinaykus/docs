"""Types for db models"""
from mypy_extensions import TypedDict


class ProcessSerializedType(TypedDict):
    """Type for serialized Process"""
    name: str
    date: str
    created_at: str
    status: str
    comment: str
