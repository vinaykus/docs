"""Typing module"""
from .db import ProcessSerializedType
from .table import TableStyleType
