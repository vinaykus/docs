"""Type definitions for types"""
from typing import Dict, List
from mypy_extensions import TypedDict


class TableStyleType(TypedDict, total=False):
    """Type for Table Styling"""
    sort_action: str
    sort_mode: str
    page_action: str
    filter_action: str
    style_cell_conditional: List[Dict]
    style_table: Dict
    style_cell: Dict[str, str]
    style_header: Dict[str, str]
