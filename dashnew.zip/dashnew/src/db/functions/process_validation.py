"""Functions for parameter validation"""
import logging
from datetime import datetime
from typing import Tuple, Optional, Union
from src.db.models import Process


def validate_date(date: Union[str, float, int, datetime]) -> Optional[datetime]:
    """Validates if the passed variable can be parsed to a date"""
    try:
        if isinstance(date, str):
            date = datetime.strptime(date, "%Y-%m-%d %H:%M:%S.%f")
        if isinstance(date, float):
            date = datetime.fromtimestamp(date)
        if isinstance(date, int):
            date = datetime.fromtimestamp(date)
        if date < datetime(1970, 1, 1) or date > datetime.utcnow():
            return None
    except Exception as error:
        logging.error("Failed to validate date: {:s}".format(str(error)))
        return None
    return date


def validate_process_content(content: dict) -> Tuple[bool, Optional[Process]]:
    """Validate process"""
    # Name
    success = True
    name = content.get("name", None)
    if name is None or not isinstance(name, str) or len(name) > 100:
        success = False

    # Status
    status = content.get("status", None)
    if status is None or not isinstance(status, str):
        success = False
    else:
        status = status.upper()

    if status not in ["SUCCESS", "FAIL"]:
        success = False

    # Comment
    comment = content.get("comment", "")
    if not isinstance(name, str) or len(comment) > 1000:
        success = False

    # Date
    date = content.get("date", datetime.utcnow())
    date = validate_date(date)

    # Return new process or None
    if not success or date is None:
        return False, None
    return True, Process(name, date, status, comment)
