"""DB functions for process table"""
import logging
from typing import Any, Dict, List, Tuple, Optional, Union
from datetime import datetime
import pandas as pd
from flask import current_app
from flask_sqlalchemy import SQLAlchemy

from src.db.models import Process
from src.db.helper import get_db_url
from src.typing import ProcessSerializedType
from .process_validation import validate_process_content


def get_processes(return_df: bool = False) -> Union[pd.DataFrame, List[ProcessSerializedType]]:
    """Get all serialized processes from db"""
    if return_df:
        return pd.read_sql_table("process", get_db_url(current_app))
    processes = [p.serialize for p in Process.query.all()]
    return processes


def add_process(db: SQLAlchemy, content: Dict[str, Any]
                ) -> Tuple[Optional[Process], int]:
    """Add a process to the db"""
    is_valid, process = validate_process_content(content)
    if not is_valid or process is None:
        return None, 405

    try:
        db.session.add(process)
        db.session.commit()
    except Exception as error:
        logging.error("Failed to add process: {:s}".format(str(error)))
        db.session.rollback()
        return None, 400
    return process, 200


def populate_db(db: SQLAlchemy) -> None:
    """Populate db if it is empty"""
    if Process.query.count() > 0:
        return None

    for process in get_dummies():
        add_process(db, process)
    return None


def get_dummies() -> List[Dict[str, Any]]:
    """Get list of dummy processes to populate db"""
    return [
        {
            "name": "OnWing Maintenance",
            "status": "SUCCESS",
            "date": datetime(2019, 1, 1, 7, 35, 13),
            "comment": "seed log",
        },
        {
            "name": "OnWing Maintenance",
            "status": "FAIL",
            "date": datetime(2019, 1, 1, 7, 35, 13),
            "comment": "seed log",
        },
        {
            "name": "OnWing Maintenance",
            "status": "success",
            "date": datetime(2019, 1, 17, 7, 35, 13),
            "comment": "seed log",
        },
        {
            "name": "Online Monitor",
            "status": "SUCCESS",
            "date": datetime(2019, 1, 17, 7, 35, 13),
            "comment": "seed log",
        },
        {
            "name": "Online Monitor",
            "status": "Fail",
            "date": datetime(2019, 2, 1, 7, 35, 13),
            "comment": "seed log",
        },
        {
            "name": "Online Monitor",
            "status": "SUCCESS",
            "date": datetime(2019, 2, 17, 7, 35, 13),
            "comment": "seed log",
        },
        {
            "name": "Dummy",
            "status": "SUCCESS",
            "date": datetime(2019, 2, 17, 7, 35, 13),
            "comment": "seed log",
        },
    ]
