"""Helper functions for db"""
import os
from typing import Optional
from sqlalchemy import create_engine
from flask import Flask

from src import SERVER_PATH, CONFIGS_PATH
from src.utils import read_config


def get_db_url(app: Optional[Flask]) -> str:
    """Return url to db"""
    sqlite_url = "sqlite:///{:s}".format(os.path.join(SERVER_PATH, "test.sqlite3"))

    # Return sqlite url for users inside CI (there is no server.json)
    if not os.path.isfile(os.path.join(CONFIGS_PATH, "server.json")):
        return sqlite_url

    # Return sqlite url for main tables when started with test configuration
    if app is not None and app.config["SERVER_CONFIG"]["DB_SUFFIX"] == "_test":
        return sqlite_url

    # Get db suffix from app configuration and use no suffix for users table
    db_suffix = "" if app is None else app.config["SERVER_CONFIG"]["DB_SUFFIX"]

    # Read config and set db name
    config = read_config("db.json")
    db_name = config["db"] + db_suffix

    # Create Mysql db if not existent and return url to new db
    template = "mysql+pymysql://{:s}:{:s}@{:s}"
    mysql_url = template.format(config["user"], config["password"], config["host"])
    engine = create_engine(mysql_url)
    engine.execute("CREATE DATABASE IF NOT EXISTS {:s} ;".format(db_name))
    return "{:s}:{:s}/{:s}".format(mysql_url, config["port"], db_name)
