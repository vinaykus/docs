"""Module for db definition and interaction"""
from .db_main import db, init_db
from .db_user import DB_SESSION_USER
