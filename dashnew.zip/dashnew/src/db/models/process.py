"""Model for Process using flask-sqlalchemy"""
from datetime import datetime
from sqlalchemy import Column, String, DateTime
from src.typing import ProcessSerializedType
from src.db import db


def dump_datetime(date: datetime) -> str:
    """dumps a datetime object to string"""
    return date.strftime("%Y-%m-%d %H:%M:%S.%f")


class Process(db.Model):  # type:ignore
    """Process model definition"""
    name = Column(String(100), primary_key=True)
    date = Column(DateTime, primary_key=True)
    created_at = Column(DateTime, nullable=False)
    status = Column(String(7), nullable=False)
    comment = Column(String(1000), nullable=False)

    def __init__(self, name: str, date: datetime, status: str, comment: str = "") -> None:
        """Init object with data"""
        self.name = name
        self.date = date
        self.status = status
        self.comment = comment
        self.created_at = datetime.utcnow()

    @property
    def serialize(self) -> ProcessSerializedType:
        """Serializes object by dumping datetime"""
        return {
            "name": self.name,
            "date": dump_datetime(self.date),
            "created_at": dump_datetime(self.created_at),
            "status": self.status,
            "comment": self.comment,
        }

    def __repr__(self) -> str:
        date = self.date.strftime("%Y-%m-%d %H:%M:%S")
        created_at = self.created_at.strftime("%Y-%m-%d %H:%M:%S")
        template = "('Process': '{: s}', {:s}, {:s}, '{: s}', '{: s}')"
        return template.format(self.name, date, created_at, self.status, self.comment)
