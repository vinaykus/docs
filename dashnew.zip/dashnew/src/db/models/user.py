"""User classes for flask login using sqlalchemy's declarative base"""
from flask_login import AnonymousUserMixin, UserMixin
from sqlalchemy import Column, String, Integer, Boolean
from src.db.db_user import BASE_USER


class TestUser(AnonymousUserMixin):
    """Anonymous user class"""
    name = "test"

    @property
    def is_authenticated(self) -> bool:
        """Return that user is not authenticated"""
        return True

    @staticmethod
    def get_email() -> str:
        """Return email of user"""
        return "anonymous@www.com"

    @staticmethod
    def get_full_name() -> str:
        """Return full name of user"""
        return "Anonymous User"

    @staticmethod
    def get_first_name() -> str:
        """Return first name of user"""
        return "Anonymous"

    @staticmethod
    def get_last_name() -> str:
        """Return last name of user"""
        return "User"

    @staticmethod
    def get_initials() -> str:
        """Return intials of user"""
        return "XXX"


class User(UserMixin, BASE_USER):  # type:ignore
    """User class"""
    __tablename__ = "users"
    id: int = Column("user_id", Integer, primary_key=True)
    active: bool = Column("active", Boolean, default=False)
    name: str = Column("name", String(100))
    email: str = Column("email", String(50), unique=True, index=True)
    first_name: str = Column("first_name", String(50))
    last_name: str = Column("last_name", String(50))

    def __init__(self, email: str, active: bool = True) -> None:
        """Init user and use email to get name etc"""
        self.email = email
        self.active = active
        self.name = email.split("@")[0].replace(".", " ").title()
        self.first_name = self.name.split(" ")[0]
        self.last_name = self.name.split(" ")[-1]

    def get_id(self) -> int:
        """Return user id"""
        return self.id

    def get_email(self) -> str:
        """Return email of user"""
        return self.email

    def get_full_name(self) -> str:
        """Return full name of user"""
        return self.name

    def get_first_name(self) -> str:
        """Return first name of user"""
        return self.first_name

    def get_last_name(self) -> str:
        """Return last name of user"""
        return self.last_name

    def get_initials(self) -> str:
        """Return intials of user"""
        splitted_name = self.email.split("@")[0].split(".")
        return "".join([part[0].upper() for part in splitted_name])
