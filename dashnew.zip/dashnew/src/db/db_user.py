"""User DB"""
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy.ext.declarative import declarative_base

from .helper import get_db_url


def init_db() -> None:
    """Create tables and initialize query property"""
    from .models import User  # noqa, pylint: disable=W0611

    BASE_USER.query = DB_SESSION_USER.query_property()
    BASE_USER.metadata.create_all(DB_USER_ENGINE)


BASE_USER = declarative_base()  # pylint: disable=C0103
DB_URL = get_db_url(None)
DB_USER_ENGINE = create_engine(DB_URL)
DB_SESSION_USER = scoped_session(sessionmaker(bind=DB_USER_ENGINE))

init_db()
