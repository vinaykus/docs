"""Main db connection (DOIT)"""
import warnings
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

from .helper import get_db_url


def init_db(app: Flask) -> None:
    """Import models, configure app and create tables"""
    from .models import Process  # noqa, pylint: disable=W0611

    db_url = get_db_url(app)
    app.config["SQLALCHEMY_DATABASE_URI"] = db_url
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    if "mysql" in db_url:
        app.config['SQLALCHEMY_POOL_RECYCLE'] = 280
        app.config['SQLALCHEMY_POOL_SIZE'] = 100
    db.init_app(app)
    db.create_all()

    if app.config["SERVER_CONFIG"]["POPULATE_DB"]:
        # Import must be placed here as models need to be imported first
        # --> This circumvents circular dependencies
        from .functions import populate_db

        try:
            populate_db(db)
        except Exception as error:
            logging.error(str(error))


db = SQLAlchemy()
warnings.filterwarnings("ignore", module="pymysql")
