"""Dashboard for data exploration"""
import os
from flask import Flask
from dash import Dash
from dash_bootstrap_components import themes

from src import SERVER_PATH
from src.dash_ui import serve_layout, create_callbacks


def create_dashboard(app: Flask) -> Dash:
    """Create the dashboard"""
    debug = app.config["SERVER_CONFIG"]["DEBUG"]
    base_link = app.config["SERVER_CONFIG"]["BASE_LINK"]

    dash = Dash(__name__, server=app,
                assets_folder=os.path.join(SERVER_PATH, "dash_ui", "assets"),
                external_scripts=["https://code.jquery.com/jquery-3.3.1.min.js"],
                external_stylesheets=[
                    themes.BOOTSTRAP,
                    "https://use.fontawesome.com/releases/v5.8.2/css/all.css"
                ],
                suppress_callback_exceptions=~debug,
                requests_pathname_prefix=base_link + "/",
                meta_tags=[{
                    "name": "viewport",
                    "content": "width=device-width, initial-scale=1"
                }])

    dash.title = "Feng Dashboard"
    dash.layout = serve_layout(debug)
    dash.enable_dev_tools(debug, dev_tools_props_check=False)
    create_callbacks(dash)
    return dash
