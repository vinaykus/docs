"""Server tests with SQLalchemy"""
import os
import json
import unittest
from typing import List, Dict
from datetime import datetime
from flask import Flask

from .db import init_db, db
from .db.models import Process
from .db.functions import add_process, populate_db, get_processes
from .utils import read_config
from .server import init_logger, init_swag, create_endpoints


class DBTests(unittest.TestCase):
    """Test for DB and Flask server"""

    def setUp(self) -> None:
        """
            Creates a new database for the unit test to use
            It is also important to use the important server as app in order to test the routes
            However, the server object is not the same as already started in run.py
        """
        config = read_config("server.json")
        self.app = Flask(__name__)
        self.app.secret_key = config["SECRET_KEY"]
        self.app.config["SERVER_CONFIG"] = config["TESTING"]
        self.app.config["TESTING"] = True
        self.app.app_context().push()

        init_db(self.app)
        init_swag(self.app)
        init_logger("TESTING")
        create_endpoints(self.app)

        self.client = self.app.test_client()

    def tearDown(self) -> None:
        """Ensures that the database is emptied for next unit test"""
        db.drop_all()
        db.session.close()  # pylint: disable=no-member
        os.remove(self.app.config["SQLALCHEMY_DATABASE_URI"].replace("sqlite:///", ""))

    # TEST ROUTES
    def test_add_process(self) -> None:
        """Test if server adds process if it gets correct json"""
        content = {
            "name": "_Test",
            "status": "SUCCESS",
            "date": "2019-03-26 14:26:56.056020",
        }
        response = self.client.post("/process",
                                    data=json.dumps(content),
                                    content_type="application/json")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Process.query.count(), 1)

    def test_get_process(self) -> None:
        """Test if server redirects on index route"""
        content = {
            "name": "On Wing",
            "status": "SUCCESS",
            "date": "2019-03-26 14:26:56.056020",
        }
        add_process(db, content)
        response = self.client.get("/process")

        processes = response.get_json()
        self.assertEqual(len(processes), 1)
        self.assertEqual(processes[0]["date"], content["date"])
        self.assertEqual(response.status_code, 200)

    # TEST DB FUNCTIONALITY
    def test_empty_db(self) -> None:
        """test if db is initially empty"""
        count = Process.query.count()
        self.assertEqual(count, 0)

    def test_populate_db(self) -> None:
        """test if db is not empty after being populated"""
        populate_db(db)
        count = Process.query.count()
        self.assertGreater(count, 0)

    def test_add_valid_process(self) -> None:
        """test if db is empty"""
        content = {
            "name": "On Wing",
            "status": "SUCCESS",
            "date": "2019-03-26 14:26:56.056020",
            "comment": "test",
        }
        add_process(db, content)

        count = Process.query.count()
        self.assertEqual(count, 1)

        processes = get_processes()
        self.assertEqual(len(processes), 1)

        process_serial = processes[0]
        is_subset = set(content.items()).issubset(set(process_serial.items()))

        self.assertTrue(is_subset)
        self.assertEqual(len(process_serial), 5)
        self.assertIsInstance(process_serial["name"], str)
        self.assertIsInstance(process_serial["status"], str)
        self.assertIsInstance(process_serial["date"], str)
        self.assertIsInstance(process_serial["created_at"], str)
        self.assertIsInstance(process_serial["comment"], str)

        process = Process.query.first()
        self.assertIsInstance(process, Process)
        self.assertIsInstance(process.name, str)
        self.assertIsInstance(process.status, str)
        self.assertIsInstance(process.comment, str)
        self.assertIsInstance(process.date, datetime)
        self.assertIsInstance(process.created_at, datetime)

    def test_add_more_valid_processes(self) -> None:
        """add more valid processes but with different data"""
        contents = [
            {
                "name": "On Wing",
                "status": "SUCCESS",
            },
            {
                "name": "On Wing",
                "status": "success",
                "comment": "test",
            },
            {
                "name": "On Wing",
                "status": "SUCCESS",
                "date": 1553068848.691304,
            },
            {
                "name": "On Wing",
                "status": "SUCCESS",
                "date": 1553068848,
            },
            {
                "name": "On Wing",
                "status": "FAIL",
                "date": "2019-03-19 14:44:26.141144",
            },
        ]  # type: List[Dict]
        for content in contents:
            add_process(db, content)

        count = Process.query.count()
        self.assertEqual(count, len(contents))

    def test_makes_upper(self) -> None:
        """Tests if status is stored in upper case"""
        content = {
            "name": "On Wing",
            "status": "success",
        }
        add_process(db, content)
        process = Process.query.first()
        self.assertEqual(process.status, "SUCCESS")

    def test_duplicates(self) -> None:
        """Tests if duplicates can be added"""
        content = {
            "name": "On Wing",
            "status": "SUCCESS",
            "date": "2019-03-19 14:44:26.141144",
        }
        process, code = add_process(db, content)
        success = process is not None
        self.assertTrue(success)
        self.assertEqual(code, 200)

        process, code = add_process(db, content)
        success = process is not None
        self.assertFalse(success)
        self.assertEqual(code, 400)
        self.assertEqual(Process.query.count(), 1)

    def test_invalid_status(self) -> None:
        """Test invalid status strings which differ from success or fail"""
        contents = [
            {
                "name": "On Wing",
                "status": "SUCCESSFUL",
            },
            {
                "name": "On Wing",
                "status": "FAILED",
            },
            {
                "name": "On Wing",
                "status": "some-string",
            },
        ]  # type: List[Dict]
        self.assert_wrong_contents_fail(contents, 405)

    def test_invalid_names(self) -> None:
        """Tests if too long names and other data types than str are not accepted"""
        contents = [
            {
                "name": "C" * 101,
                "status": "SUCCESS",
            },
            {
                "name": 1,
                "status": "FAIL",
            },
            {
                "name": ["On Wing"],
                "status": "SUCCESS",
            },
        ]  # type: List[Dict]
        self.assert_wrong_contents_fail(contents, 405)

    def test_invalid_comments(self) -> None:
        """Tests if too long comments and other data types than str are not accepted"""
        contents = [
            {
                "name": "C" * 101,
                "status": "SUCCESS",
                "comment": "test" * 1000,
            },
            {
                "name": 1,
                "status": "FAIL",
                "comment": 3,
            },
            {
                "name": ["On Wing"],
                "status": "SUCCESS",
                "comment": ["SUCCESS"],
            },
        ]  # type: List[Dict]
        self.assert_wrong_contents_fail(contents, 405)

    def test_missing_fields(self) -> None:
        """Tests if contents with missing name or status are not accepted"""
        contents = [
            {
                "status": "SUCCESS",
            },
            {
                "name": "On Wing",
            },
        ]
        self.assert_wrong_contents_fail(contents, 405)

    def test_invalid_dates(self) -> None:
        """Tests if invalid dates are not accepted"""
        contents = [
            {
                "name": "On Wing",
                "status": "SUCCESS",
                "date": "some string which is not a date",
            },
            {
                "name": "On Wing",
                "status": "SUCCESS",
                "date": "2019.03.19 14:44:26.141144",
            },
            {
                "name": "On Wing",
                "status": "SUCCESS",
                "date": "2019-03-19 14:44:26",
            },
            {
                "name": "On Wing",
                "status": "SUCCESS",
                "date": "1553068848.88",
            },
            {
                "name": "On Wing",
                "status": "SUCCESS",
                "date": datetime(1969, 1, 1),
            },
            {
                "name": "On Wing",
                "status": "SUCCESS",
                "date": datetime(2100, 1, 1),
            },
            {
                "name": "On Wing",
                "status": "SUCCESS",
                "date": [2019, 1, 1],
            },
        ]  # type: List[Dict]
        self.assert_wrong_contents_fail(contents, 405)

    def assert_wrong_contents_fail(self, contents: List[dict], error_code: int) -> None:
        """Assert wrong contents fail with specified error"""
        for content in contents:
            process, code = add_process(db, content)
            success = process is not None
            self.assertFalse(success)
            self.assertEqual(code, error_code)
