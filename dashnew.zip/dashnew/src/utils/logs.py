"""Send log to Online Monitor using function or decorator"""
import logging
from typing import Any, List, Dict
import requests


def send_log_to_om(name: str, message: str, status: str = "FAIL") -> None:
    """Post log to om"""
    try:
        body = {
            "name": name,
            "status": status,
            "comment": message
        }
        base = "https://deberpp-aps010v.rolls-royce.local/Online_Monitor/OnlineMonitor.wsgi/"
        url = "{:s}process".format(base)
        requests.post(url, verify=False, json=body, timeout=2)
    except Exception:
        print("OM request failed")


def with_log(name: str, message: str) -> Any:
    """outer wrapper
    Usage: Decorate a function to catch errors and send a log to the Online Monitor

    @with_log("Starter", "Failed to do something: ")
    def risky_function():
        print(1/0)
    """
    def inner_with_log(function: Any) -> Any:
        """inner wrapper"""
        def function_wrapper(*args: List, **kwargs: Dict) -> Any:
            """function to execute"""
            try:
                return function(*args, **kwargs)
            except Exception as error:
                full_message = message + str(error)
                logging.info(full_message)
                send_log_to_om(name, full_message)
        return function_wrapper
    return inner_with_log
