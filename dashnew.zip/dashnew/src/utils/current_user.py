"""Decorator for accessing flask current user"""
from typing import Any
import logging


def try_(user: Any, function: Any, default: str = "") -> Any:
    """Outer wrapper"""
    try:
        return eval("user.{:s}()".format(function))  # pylint: disable=W0123
    except Exception as error:
        template = "failed inside try_ wrapper, {:s}, {:s}: {:s}"
        logging.debug(template.format(str(user), function, str(error)))
        return default
