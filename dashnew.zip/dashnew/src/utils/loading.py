"""Functions for loading files"""
import os
import json
from typing import Dict
from src import CONFIGS_PATH, FOLDER_NAME


def read_config(name: str = "") -> Dict:
    """Reads and returns a json config"""
    path = os.path.join(CONFIGS_PATH, name)
    if not os.path.isfile(path):
        path = path.replace(".json", "_sample.json")
    with open(path, "r") as config_file:
        config: Dict = json.load(config_file)
        if name == "server.json":
            base = "BASE_LINK"
            config["PROD"][base] = config["PROD"][base].replace("<folder>", FOLDER_NAME)
            config["DEV"][base] = config["DEV"][base].replace("<folder>", FOLDER_NAME)
        return config
