"""Login Functionality using either AZURE AD or LDAP"""
import os
import logging
from typing import Any
from flasgger import swag_from
from flask import Flask, request, redirect, current_app, url_for
from flask_login import login_user, logout_user, current_user, login_required
from flask_ldap3_login import LDAP3LoginManager
from flask_dance.contrib.azure import make_azure_blueprint, azure
from oauthlib.oauth2.rfc6749.errors import InvalidGrantError, TokenExpiredError

from src import SWAG_PATH
from src.utils import read_config
from src.db import DB_SESSION_USER
from src.db.models import User


def add_user(user: User) -> None:
    """Create or update db user"""
    try:
        DB_SESSION_USER.add(user)  # pylint: disable=E1101
        DB_SESSION_USER.commit()  # pylint: disable=E1101
    except Exception as error:
        logging.error(str(error))
        DB_SESSION_USER.rollback()  # pylint: disable=E1101


@swag_from(os.path.join(SWAG_PATH, "logout.yml"))
@login_required
def logout() -> Any:
    """Logout user"""
    # Flask-login user logout
    user = current_user
    user.active = False
    add_user(user)
    logout_user()

    # Eventually logout from Azure and redirect to home
    config = current_app.config["SERVER_CONFIG"]
    if request.args.get("switch", "false").lower() == "true":
        del current_app.blueprints["azure"].token
        redirect_url = config["REDIRECT_URL"] + config["BASE_LINK"] + "/login"
        client_id = read_config("azure.json")["CLIENT_ID"]
        base = "https://login.microsoftonline.com/{:s}/oauth2/".format(client_id)
        return redirect("{:s}logout?post_logout_redirect_uri={:s}".format(base, redirect_url))
    return redirect(config["BASE_LINK"] + "/")


def get_login(app: Flask) -> Any:
    """Return login function"""
    return {
        "LDAP": login_ldap,
        "AZURE": login_azure
    }.get(app.config["SERVER_CONFIG"]["AUTH_MODE"], login_ldap)(app)


def login_ldap(app: Flask) -> Any:
    """Login wrapper"""
    # Create ldap_manager for validation of user credentials
    ldap_config = read_config("ldap.json")
    ldap_manager = LDAP3LoginManager()
    ldap_manager.init_config(ldap_config)
    base_link = app.config["SERVER_CONFIG"]["BASE_LINK"] + "/"

    @swag_from(os.path.join(SWAG_PATH, "login.yml"))
    def _login_ldap() -> Any:
        """Real login"""
        email: str = request.args.get("email", "")
        password: str = request.args.get("password", "")

        try:
            response = ldap_manager.authenticate(email, password)
            if response.status.name == "fail":
                return redirect(base_link)
        except Exception as error:
            logging.error("{:s} for user: {:s}".format(str(error), email))
            return redirect(base_link)

        login_user_and_store_in_db(email)
        return redirect(base_link)
    return _login_ldap


def login_azure(app: Flask) -> Any:
    """Login wrapper"""
    # Create azure blueprint for checking if users are authorized
    # If not -> redirect to azure login
    #        -> after successful oauth dance redirect to login again
    #        -> this time, the user will be authorized
    # If yes -> fetch user info, update db and log-in user
    azure_config = read_config("azure.json")
    blueprint = make_azure_blueprint(
        tenant=azure_config["TENANT"],
        client_id=azure_config["CLIENT_ID"],
        client_secret=azure_config["CLIENT_SECRET"],
        redirect_url="/login"
    )
    app.register_blueprint(blueprint, url_prefix="/login")
    base_link = app.config["SERVER_CONFIG"]["BASE_LINK"] + "/"

    @swag_from(os.path.join(SWAG_PATH, "login.yml"))
    def _login_azure() -> Any:
        """Real login"""
        if not azure.authorized:
            return redirect(url_for("azure.login"))
        try:
            info = azure.get("/v1.0/me").json()
        except (InvalidGrantError, TokenExpiredError) as error:
            logging.error(error)
            return redirect(url_for("azure.login"))
        login_user_and_store_in_db(info["userPrincipalName"])
        return redirect(base_link)
    return _login_azure


def login_user_and_store_in_db(email: str) -> None:
    """Logs a user in based on the retrieved email"""
    user_from_db = User.query.filter_by(email=email).first()
    if user_from_db is None:
        user = User(email)
    else:
        user = user_from_db
        user.active = True

    add_user(user)
    login_user(user, remember="yes")
