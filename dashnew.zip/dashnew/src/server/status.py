"""Functions for evaluating if server runs fine and passes checks/tests"""
import os
import ast
import logging
from subprocess import PIPE, Popen
from typing import Dict, List, Union, Tuple
from joblib import Parallel, delayed

from src import PROJECT_PATH


def get_color(n_messages: int, max_n: int = 5) -> str:
    """Get color based on number of messages"""
    if n_messages < 1:
        return "green"
    if 1 < n_messages <= max_n:
        return "yellow"
    return "red"


def get_linting_command(config: Dict) -> str:
    """Get linting command"""
    pylint = "{:s}pylint".format(config["COMMAND_PREFIX"])
    files = [os.path.join(PROJECT_PATH, f) for f in ["run.py", "src"]]
    pylintrc = os.path.join(PROJECT_PATH, ".pylintrc")
    template = "{:s} {:s} -f json --rcfile {:s}"
    return template.format(pylint, " ".join(files), pylintrc)


def get_flake8_command(config: Dict) -> str:
    """Get flake8 command"""
    flake8 = "{:s}flake8".format(config["COMMAND_PREFIX"])
    return "{:s} {:s}".format(flake8, PROJECT_PATH)


def get_mypy_command(config: Dict) -> str:
    """Get mypy command"""
    mypy = "{:s}mypy".format(config["COMMAND_PREFIX"])
    mypy_ini = os.path.join(PROJECT_PATH, "mypy.ini")
    template = "{:s} {:s} --config-file {:s}"
    return template.format(mypy, PROJECT_PATH, mypy_ini)


def get_test_command(config: Dict) -> str:
    """Get test command"""
    python = "{:s}{:s}".format(config["COMMAND_PREFIX"], config["PYTHON"])
    template = "{:s} -m unittest discover {:s} --quiet -p ' * _test.py'"
    return template.format(python, PROJECT_PATH)


def get_metric(config: Dict, metric: str) -> Tuple[Union[int, str], str]:
    """Get number of linting messages"""
    try:
        # Get command
        command = {
            "linting": get_linting_command,
            "flake8": get_flake8_command,
            "mypy": get_mypy_command,
            "testing": get_test_command
        }[metric](config)
        logging.debug(command)

        # Execute command
        process = Popen(command, stdout=PIPE, shell=True)
        if metric == "linting":
            message_string = process.stdout.read().decode("utf-8")
            messages = ast.literal_eval(message_string)
        elif metric == "testing":
            _ = process.communicate()[0]
            return (True, "green") if process.returncode == 0 else (False, "red")
        else:
            messages = process.stdout.readlines()
    except Exception as error:
        logging.error("{:s} error: {:s}".format(metric, str(error)))
        return str(error), "red"

    # Log messages
    for message in messages:
        logging.debug(message)
    return len(messages), get_color(len(messages))


def get_own_status(config: Dict) -> Dict[str, Union[str, bool, int, List[str]]]:
    """Get status of own server - must be called from root directory"""
    checks = {
        "flake8_warnings": "flake8",
        "linter_warnings": "linting",
        "mypy_warnings": "mypy",
        "passed_tests": "testing"
    }

    # Compute metrics
    results = Parallel(n_jobs=len(checks.values()), prefer="threads")([
        delayed(get_metric)(config, metric) for metric in checks.values()
    ])

    # Unzip and format results
    status, colors = {}, {}
    for i, key in enumerate(checks.keys()):
        status[key], colors[key] = results[i]
    status["colors"] = [colors[key] for key in status]

    logging.debug("Own Status: {:s}".format(str(status)))
    return status
