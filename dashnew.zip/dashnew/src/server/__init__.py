"""Module for server helper"""
from .swag import init_swag
from .logger import init_logger
from .api import create_endpoints
