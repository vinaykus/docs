"""Functions for downloading data or getting server status"""
import os
from typing import Any
from flask import jsonify, current_app, request
from flasgger import swag_from
from flask_login import login_required

from src import SWAG_PATH
from src.db import db
from src.db.functions import get_processes, add_process
from .status import get_own_status


@swag_from(os.path.join(SWAG_PATH, "statusGet.yml"))
def status() -> Any:
    """Route for checking if service runs smoothly"""
    config = current_app.config["SERVER_CONFIG"]
    return jsonify(get_own_status(config)), 200, {"ContentType": "application/json"}


@swag_from(os.path.join(SWAG_PATH, "processGet.yml"))
@login_required
def get_process_route() -> Any:
    """Route for checking if service runs smoothly"""
    processes = get_processes()
    return jsonify(processes), 200, {"ContentType": "application/json"}


@swag_from(os.path.join(SWAG_PATH, "processPost.yml"))
@login_required
def add_process_route() -> Any:
    """Route for checking if service runs smoothly"""
    content = request.get_json(force=True)
    process, code = add_process(db, content)
    return jsonify({"success": process is not None}), code, {
        "ContentType": "application/json"
    }
