"""Logger class which redirects prints and logs to own log folder"""
import os
import sys
from typing import Any
import logging
from src import DATA_PATH


class LoggerWriter:
    """Class needed for writing stdout and stderr to logs as well"""

    def __init__(self, logger: Any, level: Any, out: Any) -> None:
        """Init class"""
        self.logger, self.level, self.out = logger, level, out

    def write(self, message: str) -> None:
        """Write message to file"""
        self.out.write(message)
        if message.rstrip():
            self.logger.log(self.level, message.rstrip())

    def flush(self) -> None:
        """Flush"""


def init_logger(mode: str) -> None:
    """Initializes the logger"""
    # Create log folder
    logfile = os.path.join(DATA_PATH, "logs", "{:s}.log".format(mode.lower()))
    os.makedirs(os.path.join(DATA_PATH, "logs"), exist_ok=True)

    # Basic config
    level = logging.ERROR if mode in ["DEV", "PROD"] else logging.DEBUG
    template = "%(asctime)s - %(module)s - %(levelname)s - %(message)s"
    logging.basicConfig(filename=logfile, level=level,
                        format=template, datefmt="%Y-%m-%d %H:%M:%S")

    # Suppress info loggings of werkzeug, urllilb3 and oauth (writes secrets in debug!!!)
    logging.getLogger("werkzeug").setLevel(level)
    logging.getLogger("oauth2").setLevel(logging.ERROR)
    logging.getLogger("requests_oauthlib").setLevel(logging.ERROR)
    logging.getLogger("urllib3.connectionpool").setLevel(level)

    # Stdout & Stderr writing
    root = logging.getLogger()
    sys.stdout = LoggerWriter(root, logging.INFO, sys.stdout)  # type: ignore
    sys.stderr = LoggerWriter(root, logging.ERROR, sys.stderr)  # type: ignore

    # Start logging
    logging.info("")
    logging.info("*" * 40)
    logging.info("Starting the application")
    logging.info("*" * 40)
    logging.info("")
