"""Api"""
from typing import Any
from flask import Flask
from flask_login import LoginManager

from src.db import DB_SESSION_USER
from src.db.models import User, TestUser
from .api_routes import status, add_process_route, get_process_route
from .api_login import get_login, logout


def create_endpoints(app: Flask) -> None:
    """Create endpoints"""
    # Endpoints
    app.route("/status", methods=["GET"])(status)
    app.route("/process", methods=["GET"])(get_process_route)
    app.route("/process", methods=["POST"])(add_process_route)

    # Db specific
    def shutdown_session(__: Any = None) -> None:
        DB_SESSION_USER.remove()
    app.teardown_appcontext(shutdown_session)

    # Login
    app.route("/logout", methods=["GET"])(logout)
    app.route("/login", methods=["GET"])(get_login(app))

    def load_user(user_id: str) -> Any:
        """Get user from global dictionary"""
        return User.query.get(int(user_id))

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = app.config["SERVER_CONFIG"]["BASE_LINK"] + "/"
    login_manager.user_loader(load_user)

    if app.config["SERVER_CONFIG"]["AUTH_MODE"] == "NONE":
        login_manager.anonymous_user = TestUser
