"""Functions to initialize swagger api documentation"""
import os
from textwrap import dedent
import yaml
from flask import Flask
from flasgger import Swagger

from src import SWAG_PATH


def get_polyfill() -> str:
    """POLYFILL for IE which does not know Object.assign()"""
    return dedent("""
        <script>
            if (typeof Object.assign != "function") {
                Object.assign = function(target) {
                    "use strict";
                    if (target == null) {
                        throw new TypeError("Cannot convert undefined or null to object");
                    }
                    target = Object(target);
                    for (var index = 1; index < arguments.length; index++) {
                        var source = arguments[index];
                        if (source != null) {
                            for (var key in source) {
                                if (Object.prototype.hasOwnProperty.call(source, key)) {
                                    target[key] = source[key];
                                }
                            }
                        }
                    }
                    return target;
                };
            }
        </script>
    """)


def init_swag(app: Flask) -> None:
    """Adds some swag to the app"""
    config = app.config["SERVER_CONFIG"]
    if config["SWAG"]:
        with open(os.path.join(SWAG_PATH, "index.yml"), "r") as stream:
            template = yaml.safe_load(stream)
            base_link = config["BASE_LINK"]
            base_path = "/{:s}/".format(base_link) if base_link else "/"
            app.config["SWAGGER"] = {
                "footer_text": get_polyfill(),
                "basePath": base_path
            }
        Swagger(app, template=template)
