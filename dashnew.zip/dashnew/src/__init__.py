"""Main module which holds flask server and dashboard"""
import os

SERVER_PATH = os.path.dirname(os.path.abspath(__file__))
PROJECT_PATH = os.path.abspath(os.path.join(SERVER_PATH, os.pardir))
FOLDER_NAME = PROJECT_PATH.split(os.sep)[-1]

DATA_PATH = os.path.join(PROJECT_PATH, "data")
SWAG_PATH = os.path.join(DATA_PATH, "swag")
CONFIGS_PATH = os.path.join(DATA_PATH, "configs")

ASSETS_PATH = os.path.join(SERVER_PATH, "dash_ui", "assets")
