"""Test login"""
from typing import Any
from src.app import create_app
from src.dashboard import create_dashboard


def test_login_ldap(dash_duo: Any) -> None:
    """Tests if ldap login has an email and password field besides the link"""
    server = create_app("LOCAL")
    app = create_dashboard(server)
    dash_duo.start_server(app)

    dash_duo.wait_for_text_to_equal("#link-login", "Sign-In", timeout=4)
    assert dash_duo.find_element("#link-login").text == "Sign-In"
    assert dash_duo.find_element(
        "#input-login-email").get_attribute("placeholder") == "Please enter your email"
    assert dash_duo.find_element(
        "#input-login-password").get_attribute("placeholder") == "Pleace enter your password"

    assert dash_duo.get_logs() == [], "browser console should contain no error"


def test_login_azure(dash_duo: Any) -> None:
    """Tests if azure login page consists only of a link"""
    server = create_app("EXTERNAL")
    app = create_dashboard(server)
    dash_duo.start_server(app)

    dash_duo.wait_for_text_to_equal(
        "#link-login", "Sign-In with Azure Active Directory", timeout=4)
    assert dash_duo.find_element(
        "#link-login").text == "Sign-In with Azure Active Directory"

    assert dash_duo.get_logs() == [], "browser console should contain no error"
