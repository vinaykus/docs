"""Test routing"""
from typing import Any
from src.app import create_app
from src.dashboard import create_dashboard


def test_routing(dash_duo: Any) -> None:
    """Tests the links which are used to route the client"""
    server = create_app("TESTING")
    app = create_dashboard(server)
    dash_duo.start_server(app)

    dash_duo.wait_for_text_to_equal("#div-header-username", "Anonymous", timeout=4)
    assert dash_duo.find_element("#div-header-username").text == "Anonymous"

    dash_duo.multiple_click("#link-user", 1)
    dash_duo.wait_for_text_to_equal(".card-title", "Welcome Anonymous!", timeout=4)
    assert dash_duo.find_element(".card-title").text == "Welcome Anonymous!"
    assert dash_duo.find_element("#user-name").get_attribute("placeholder") == "Anonymous User"
    assert dash_duo.find_element("#user-email").get_attribute("placeholder") == "anonymous@www.com"
    assert dash_duo.find_element("#user-auth").get_attribute("placeholder") == "None"

    dash_duo.multiple_click("#link-", 1)
    dash_duo.wait_for_text_to_equal("#h1-main", "Welcome to the main page!", timeout=4)
    assert dash_duo.find_element("#h1-main").text == "Welcome to the main page!"

    dash_duo.multiple_click("#link-user", 1)
    dash_duo.wait_for_text_to_equal(".card-title", "Welcome Anonymous!", timeout=4)
    assert dash_duo.find_element(".card-title").text == "Welcome Anonymous!"

    dash_duo.multiple_click("#button-back", 1)
    dash_duo.wait_for_text_to_equal("#h1-main", "Welcome to the main page!", timeout=4)
    assert dash_duo.find_element("#h1-main").text == "Welcome to the main page!"

    assert dash_duo.get_logs() == [], "browser console should contain no error"
