"""Test creation of app"""
import os
import codecs
from typing import Any
from difflib import SequenceMatcher
from src import SERVER_PATH
from src.app import create_app
from src.dashboard import create_dashboard
from src.db import db
from src.db.functions import populate_db


def read_html(name: str) -> str:
    """Read html file for comparing ui elements which are static"""
    folder = os.path.join(SERVER_PATH, "dash_integration_tests", "images")
    with codecs.open(os.path.join(folder, name + ".html"), "r") as text_file:
        return text_file.read().replace("\n", "").replace(" ", "")


def test_main_page(dash_duo: Any) -> None:
    """Test main page for having a table and plot"""
    server = create_app("TESTING")
    app = create_dashboard(server)
    populate_db(db)
    dash_duo.start_server(app)

    dash_duo.wait_for_text_to_equal("#h1-title", "Starter Project", timeout=4)
    assert dash_duo.find_element("#h1-title").text == "Starter Project"

    dash_duo.wait_for_text_to_equal("#div-header-username", "Anonymous", timeout=4)
    assert dash_duo.find_element("#div-header-username").text == "Anonymous"

    dash_duo.wait_for_text_to_equal("#h1-main", "Welcome to the main page!", timeout=4)
    assert dash_duo.find_element("#h1-main").text == "Welcome to the main page!"

    dash_duo.wait_for_element("#table-main", timeout=4)
    table_html = dash_duo.find_element("#table-main").get_attribute("outerHTML")
    table_html = table_html.replace("\n", "").replace(" ", "")
    ratio = SequenceMatcher(a=table_html, b=read_html("dashboard_table")).ratio()
    assert ratio > 0.95, "table should almost match stored html"

    # Cannot assert on that as it changes each run
    dash_duo.wait_for_element("#plot-main", timeout=4)

    assert dash_duo.get_logs() == [], "browser console should contain no error"
