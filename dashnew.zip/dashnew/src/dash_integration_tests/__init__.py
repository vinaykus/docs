"""Module for integration tests - must be a module to import the dashboard"""
