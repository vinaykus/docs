"""Flask Server"""
from flask import Flask
from src.db import init_db
from src.utils import read_config
from src.server import init_logger, init_swag, create_endpoints


def create_app(mode: str) -> Flask:
    """Initialize ldap & login manager and logger as well as endpoints"""
    # Init app
    app = Flask(__name__)
    config = read_config("server.json")
    app.secret_key = config["SECRET_KEY"]
    app.config["SERVER_CONFIG"] = config[mode]
    app.app_context().push()

    # Init db, logger, swag and create endpoints
    init_logger(mode)
    init_swag(app)
    init_db(app)
    create_endpoints(app)
    return app
