function interpolate(text, arguments) {
  // template = "Construct a '.%s' based on a '.%s'";
  // placeholder = interpolate(template, ["string", "template"]);
  var _r = function(p, c) {
    return p.replace(/%s/, c);
  };
  return arguments.reduce(_r, text);
}

Array.prototype.groupBy = function(prop) {
  return this.reduce(function(groups, item) {
    const val = item[prop];
    groups[val] = groups[val] || [];
    groups[val].push(item);
    return groups;
  }, {});
};
