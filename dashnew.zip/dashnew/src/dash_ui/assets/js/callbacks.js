$(document).ready(function() {
  if (!window.dash_clientside) {
    window.dash_clientside = {};
  }
  window.dash_clientside.clientside = {
    // SHARED
    update_header: function(data) {
      // Returns username for username-div in header
      return data["USER_NAME"];
    },

    // LOGIN
    update_login_link: function(data, email, password) {
      // Updates login link with email/password in case of ldap
      loginLink = "/login";
      if (email && password) {
        loginLink += "?email=" + email + "&password=" + password;
      }
      return data["BASE_LINK"] + loginLink;
    },
    validate_email: function(email) {
      // Validates email in login form
      if (email) {
        isValid = email.toLowerCase().endsWith("@rolls-royce.com");
        return [isValid, !isValid];
      }
      return [false, false];
    },
    create_main_plot: function(_, data) {
      if (!data) {
        return { display: "none" };
      }

      const frequencies = {
        SUCCESS: {},
        FAIL: {}
      };

      Object.values(data["date"]).forEach(function(date, i) {
        frequencies["SUCCESS"][date] = frequencies["SUCCESS"][date] || 0;
        frequencies["FAIL"][date] = frequencies["FAIL"][date] || 0;
        frequencies[data["status"][i]][date]++;
      });

      const traces = ["SUCCESS", "FAIL"].map(function(value) {
        return {
          x: Object.keys(frequencies[value]),
          y: Object.values(frequencies[value]),
          name: value,
          type: "bar"
        };
      });

      const layout = {
        title: "Super fast client-side plot",
        showlegend: true,
        margin: { l: 40, r: 0, t: 40, b: 30 },
        legend: { x: 0, y: 1 },
        barmode: "group"
      };

      Plotly.newPlot("plot-main-frontend", traces, layout);
      return { display: "none" };
    }
  };
});
