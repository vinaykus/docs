"""Callback for updating header component"""
from dash import Dash
from dash.dependencies import Output, Input, ClientsideFunction


def create_header_callback(dash: Dash) -> None:
    """Create the callbacks and add it to dashboard"""
    dash.clientside_callback(
        ClientsideFunction("clientside", "update_header"),
        Output("div-header-username", "children"),
        [Input("store-data-general", "data")]
    )
