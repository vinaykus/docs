"""Callbacks to create main plot"""
from dash import Dash
from dash.dependencies import Input, Output, State, ClientsideFunction


def create_main_plot_callback(dash: Dash) -> None:
    """Create the callback and add it to dashboard"""
    dash.clientside_callback(
        ClientsideFunction("clientside", "create_main_plot"),
        Output("dummy", "style"),
        [Input("dummy", "children")],
        [State("store-data-processes", "data")]
    )
