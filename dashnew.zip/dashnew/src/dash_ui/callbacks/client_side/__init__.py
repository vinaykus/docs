"""Client-Side callbacks"""
from dash import Dash
from .login import create_login_callback
from .shared import create_header_callback
from .main_plot import create_main_plot_callback


def create_client_side_callbacks(dash: Dash) -> None:
    """Create client-side callbacks"""
    create_login_callback(dash)
    create_header_callback(dash)
    create_main_plot_callback(dash)
