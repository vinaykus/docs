"""Callback for updating login route"""
from dash import Dash
from dash.dependencies import Output, Input, ClientsideFunction


def create_login_callback(dash: Dash) -> None:
    """Create callbacks for login page"""
    dash.clientside_callback(
        ClientsideFunction("clientside", "update_login_link"),
        Output("link-login", "href"),
        [Input("store-data-general", "data"),
         Input("input-login-email", "value"),
         Input("input-login-password", "value")]
    )

    dash.clientside_callback(
        ClientsideFunction("clientside", "validate_email"),
        [Output("input-login-email", "valid"),
         Output("input-login-email", "invalid")],
        [Input("input-login-email", "value")]
    )
