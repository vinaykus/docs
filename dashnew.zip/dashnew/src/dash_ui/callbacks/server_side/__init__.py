"""Server-Side callbacks"""
from dash import Dash
from .store import create_store_callback
from .routing import create_routing_callback
from .main_plot import create_main_plot_callback


def create_server_side_callbacks(dash: Dash) -> None:
    """Create server-side callbacks"""
    create_store_callback(dash)
    create_routing_callback(dash)
    create_main_plot_callback(dash)
