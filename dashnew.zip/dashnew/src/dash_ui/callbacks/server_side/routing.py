"""Callback for routing"""
from typing import Any, Tuple
from flask_login import current_user
from dash import Dash, callback_context
from dash.exceptions import PreventUpdate
from dash.dependencies import Input, Output, State
from dash_html_components import Div

from src.dash_ui.pages import create_page


def update_url_and_content(*args: Any) -> Tuple[str, Div]:
    """Update url, reroute based on clicked link and return content"""
    trigger = callback_context.triggered[0]["prop_id"].split(".")[0]
    if trigger == "store-data-general":
        if args[0]:
            url: str = args[-1]
            page = url.split("/")[-1] if current_user.is_authenticated else "login"
            return url, create_page(page)
        raise PreventUpdate

    # Each link has the form "link-<page>"
    # --> so we can use the prop_id to get the url
    # --> elements must be present in layout (add to header or create navbar)
    url = trigger.split("-")[-1]
    page = url.split("/")[-1] if current_user.is_authenticated else "login"
    return url, create_page(page)


def create_routing_callback(dash: Dash) -> None:
    """Create the callback and add it to dashboard"""
    dash.callback(
        [Output("url", "pathname"), Output("main-content", "children")],
        [Input("store-data-general", "data"),
         Input("link-user", "n_clicks"),
         Input("link-", "n_clicks")],
        [State("url", "pathname")]
    )(update_url_and_content)
