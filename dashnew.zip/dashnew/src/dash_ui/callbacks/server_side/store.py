"""Callbacks to update session storage"""
from typing import Dict
from flask import current_app
from flask_login import current_user
from dash import Dash
from dash.dependencies import Input, Output

from src.utils import try_
from src.db.functions import get_processes


def update_store_with_general_info(_: str) -> Dict:
    """Update store with user info and base link"""
    return {
        "USER_NAME": try_(current_user, "get_first_name"),
        "BASE_LINK": current_app.config["SERVER_CONFIG"]["BASE_LINK"]
    }


def update_store_with_processes(_: str) -> Dict:
    """Update store with processes from db"""
    if not current_user.is_authenticated:
        return {}
    data: Dict = get_processes(True).to_dict()  # type:ignore
    return data


def create_store_callback(dash: Dash) -> None:
    """Create the callback and add it to dashboard"""
    dash.callback(
        Output("store-data-general", "data"),
        [Input("store-data-general", "modified_timestamp")]
    )(update_store_with_general_info)

    dash.callback(
        Output("store-data-processes", "data"),
        [Input("store-data-processes", "modified_timestamp")]
    )(update_store_with_processes)
