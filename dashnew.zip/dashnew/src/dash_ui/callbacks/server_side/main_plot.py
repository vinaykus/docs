"""Callbacks to create main plot"""
from typing import Dict, List
import pandas as pd
from dash import Dash
from dash.exceptions import PreventUpdate
from dash.dependencies import Input, Output, State
from dash_html_components import Div
from dash_core_components import Graph

from src.dash_ui.elements import bar_plot


def create_main_plot(_: List, url: str, data: Dict) -> Graph:
    """Create a bar plot which plots success vs fail for each app"""
    if url == "user" or data is None or not data:
        raise PreventUpdate

    df = pd.DataFrame.from_dict(data)
    if df.empty:
        return Div("No data")
    freqs = df.groupby("date")["status"].value_counts()
    freqs = {date: freqs.loc[date].to_dict() for date in freqs.index.levels[0]}
    return bar_plot(df["date"], freqs, "plot-main", "Slow server-side plot")


def create_main_plot_callback(dash: Dash) -> None:
    """Create the callback and add it to dashboard"""
    dash.callback(
        Output("plot-main-div", "children"),
        [Input("main-content", "children")],
        [State("url", "pathname"), State("store-data-processes", "data")]
    )(create_main_plot)
