"""Callback creation"""
from dash import Dash
from .server_side import create_server_side_callbacks
from .client_side import create_client_side_callbacks


def create_callbacks(dash: Dash) -> None:
    """Create callbacks"""
    create_client_side_callbacks(dash)
    create_server_side_callbacks(dash)
