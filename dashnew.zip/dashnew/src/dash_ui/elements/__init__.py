"""Module for dash ui elements, e.g. table and filter"""
from .table import create_table,create_card_with_icon
from .plot_bar import bar_plot
