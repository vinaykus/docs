"""Function for creating a data table"""
from typing import Optional
import pandas as pd
from dash_table import DataTable
from dash_html_components import Div, H5, A, Span
import dash_bootstrap_components as dbc
from src.typing import TableStyleType
from .table_styling import get_shared_styles


def create_table(df: pd.DataFrame, t_id: str, styling: Optional[TableStyleType] = None
                 ) -> DataTable:
    """Create and return data table"""
    complete_styling = get_shared_styles(df)
    if styling is not None:
        complete_styling.update(styling)

    df_new = df.drop(columns=["created_at"])
    return DataTable(
        id=t_id, data=df_new.to_dict("records"),
        columns=[{"name": col, "id": col} for col in df_new.columns],
        **complete_styling
    )


def create_card_with_icon(icon: str, body: str) -> dbc.Card:
    """Create a card component with an icon on top"""
    return dbc.Card([
        dbc.CardHeader(Div(Span(className=icon, style={"color": "#00498f"}),
                           className="card-image-container text-center",
                           style={"padding-top": "1rem", "padding-bottom": "7rem"})),
        dbc.CardBody(H5(body), className="py-2 text-center")
    ], className="card-with-image mt-5")
