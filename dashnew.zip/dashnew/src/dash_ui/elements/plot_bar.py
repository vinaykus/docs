"""Functions for plot creation"""
from typing import List, Dict
import plotly.graph_objs as go
from dash_core_components import Graph


def bar_plot(keys: List[str], freqs: Dict[str, Dict[str, int]], graph_id: str, title: str) -> Graph:
    """Create and return a bar plot"""
    keys = list(set(keys))
    return Graph(
        id=graph_id,
        style={"height": 300},
        figure=go.Figure(
            data=[
                go.Bar(
                    x=keys,
                    y=[freqs[key].get("SUCCESS", 0) for key in keys],
                    name="SUCCESS",
                    marker=go.bar.Marker(color="green")
                ),
                go.Bar(
                    x=keys,
                    y=[freqs[key].get("FAIL", 0) for key in keys],
                    name="FAIL",
                    marker=go.bar.Marker(color="red")
                )
            ],
            layout=go.Layout(
                title=title,
                showlegend=True,
                legend=go.layout.Legend(x=0, y=1.0),
                margin=go.layout.Margin(l=40, r=0, t=40, b=30)  # noqa
            )
        )
    )
