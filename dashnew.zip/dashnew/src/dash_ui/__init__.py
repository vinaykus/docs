"""Module for defining ui of dashboard"""
from .layout import serve_layout
from .callbacks import create_callbacks
