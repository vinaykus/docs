"""User page"""
from flask import current_app
from flask_login import current_user
from dash_html_components import Div, H2, A, Span
import dash_bootstrap_components as dbc
from src.utils import try_


def create_user_card_header() -> dbc.CardHeader:
    """Return header for the user card"""
    text = "Welcome {:s}!".format(try_(current_user, "get_first_name"))
    icon = Span(className="fas fa-sign-out-alt")
    href = current_app.config["SERVER_CONFIG"]["BASE_LINK"] + "/logout"
    link = A(icon, id="link-logout", className="float-right", href=href)
    return H2([text, link], className="card-title")


def create_form(label: str, form_id: str, placeholder: str) -> dbc.FormGroup:
    """Returns form group"""
    return dbc.FormGroup([
        dbc.Label(label, html_for=form_id, width=2),
        dbc.Col(dbc.Input(form_id, placeholder=placeholder, disabled=True), width=10),
    ], row=True, className="mt-4")


def create_user_card_body() -> dbc.Form:
    """Returns the card body for the user card"""
    # Info
    config = current_app.config["SERVER_CONFIG"]
    name = create_form("Your Name", "user-name", try_(current_user, "get_full_name"))
    email = create_form("Your Email", "user-email", try_(current_user, "get_email"))
    provider = create_form("Identity Provider", "user-auth", config["AUTH_MODE"].title())

    # Buttons
    switch = None
    if config["AUTH_MODE"] == "AZURE":
        href = config["BASE_LINK"] + "/logout?switch=true"
        switch = A("Switch Account", id="link-switch", className="btn btn-danger ml-4", href=href)
    buttons = dbc.Col([
        A("Go Back", href=config["BASE_LINK"] + "/",
          id="button-back", className="btn btn-secondary"),
        switch
    ], className="text-center mt-5")
    return dbc.Form([name, email, provider, buttons])


def create_user_page() -> Div:
    """Return user page markup"""
    return dbc.Row(
        dbc.Col(dbc.Card([
            dbc.CardHeader(create_user_card_header()),
            dbc.CardBody(create_user_card_body())
        ], color="light"), xs=12, lg=10, className="offset-lg-1"),
        className="mt-5"
    )
