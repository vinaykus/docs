"""Module for pages/ compositions of UI elements"""
from dash_html_components import Div

from .shared import create_header
from .user import create_user_page
from .main import create_main_page
from .login import create_login_page


def create_page(name: str) -> Div:
    """Returns elements which are displayed in main-content"""
    return {
        "": create_main_page,
        "login": create_login_page,
        "user": create_user_page
    }.get(name, create_main_page)()
