"""Login page"""
from flask import current_app
import dash_bootstrap_components as dbc
from dash_html_components import A, Div


def create_login_page() -> Div:
    """Create either Azure or LDAP login page"""
    auth_mode = current_app.config["SERVER_CONFIG"]["AUTH_MODE"]
    base_link = current_app.config["SERVER_CONFIG"]["BASE_LINK"]
    return {
        "LDAP": create_login_page_ldap,
        "AZURE": create_login_page_azure
    }.get(auth_mode, create_login_page_ldap)(base_link)


def create_login_page_azure(base_link: str) -> Div:
    """Returns a single link for azure login"""
    href = base_link + "/login"
    text = "Sign-In with Azure Active Directory"
    return dbc.Row(className="justify-content-center mt-5", children=[
        A(text, id="link-login", className="btn btn-primary px-3 py-2", href=href),
        dbc.Input(id="input-login-email", className="d-none"),
        dbc.Input(id="input-login-password", className="d-none")
    ])


def create_login_page_ldap(base_link: str) -> Div:
    """Create login screen with a single login button"""
    href = base_link + "/login"
    return dbc.Row([
        dbc.Col(dbc.FormGroup([
            dbc.Label("Email", html_for="input-login-email", className="ml-2"),
            dbc.Input(type="email", id="input-login-email", placeholder="Please enter your email"),
            dbc.FormFeedback("Weel done! :-)", valid=True, className="ml-2"),
            dbc.FormFeedback("We only accept emails ending with @rolls-royce.com...",
                             valid=False, className="ml-2"),
        ]), xs=6, lg=4, className="offset-lg-1"),
        dbc.Col(dbc.FormGroup([
            dbc.Label("Password", html_for="input-login-password", className="ml-2"),
            dbc.Input(type="password", id="input-login-password",
                      placeholder="Pleace enter your password")
        ]), xs=6, lg=4, className="offset-lg-1"),
        dbc.Col(
            A("Sign-In", id="link-login", className="btn btn-primary px-3 py-2", href=href),
            className="text-center mt-3", width=12
        )
    ], form=True, className="mt-5")
