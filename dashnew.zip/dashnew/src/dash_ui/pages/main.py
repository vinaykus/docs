"""Main Page"""
from dash_html_components import H1, P, Hr, Div, A
from dash_core_components import Loading
from dash_bootstrap_components import Row, Col
from flask import request
from src.db.functions import get_processes
from src.dash_ui.elements import create_table,create_card_with_icon


def create_main_page() -> Row:
    """Create and return main page"""
    card_infos = [
        ("fas fa-table fa-6x", "Explore raw data in filterable and sortable tables", "data_ui"),
        ("fas fa-list-ul fa-6x", "Get explanations on each data column/ dataset", "data_ui"),
        ("fas fa-project-diagram fa-6x", "Connect your data sources in a graph", "data_ui"),
        ("fas fa-chart-area fa-6x", "Get insights from interactive charts and tables", "analytics"),
        ("fas fa-percentage fa-6x", "Compare the coverage of data between sources", "coverage"),
        ("fas fa-code fa-6x", "Explore the API to programmatically query data", "developer"),
    ]
    try:
        base_link = request.url.split("/_dash")[0]
    except Exception:
        base_link = "http://localhost:4000"
    return Div([Row([
        Col(H1("Welcome to the main page!", id="h1-main", className="text-center my-4"), xs=12),
        Col(Loading(create_table(get_processes(True), "table-main")), xs=12),
        Col(id="plot-main-div", className="mt-4", xs=6),
        Col(Div(id="plot-main-frontend", style={"height": "300px"}),
            id="plot-main-div-frontend", className="mt-4", xs=6),
        Div(id="dummy", style={"display": "none"})
    ]),
        Row([
            Col(A(create_card_with_icon(info[0], info[1]),
                  href="{:s}/{}".format(base_link, info[2]),
                  target="_blank", className="card-link"
                  ), xs=12, md=6, lg=4)
            for info in card_infos
        ])
    ])
