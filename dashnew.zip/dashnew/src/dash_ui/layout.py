"""Definition of main layout"""
from typing import Any
from flask import has_request_context
from dash_html_components import Div, Link
from dash_core_components import Location, Store
from dash_bootstrap_components import Container

from src.dash_ui.pages import create_header, create_page


def serve_layout(debug: bool = False) -> Any:
    """Function for serving layout - important for updates on page reload"""
    # Dummies are required to enable callback validation
    # --> they are not rendered in the app
    # --> they are only enabled in debug mode
    main_content = Div(id="main-content")
    if debug and not has_request_context():
        main_content = Div(id="main-content", children=[
            create_page(""),
            create_page("login"),
            create_page("user"),
        ])

    return Container(id="main", children=[
        Location(id="url", refresh=False),
        Link(rel="shortcut icon", href="favicon.ico"),
        Store(id="store-data-general", storage_type="session"),
        Store(id="store-data-processes", storage_type="session"),
        create_header(),
        main_content
    ])
