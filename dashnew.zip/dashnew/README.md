# Kickstart your Dash App by using this template!

This repository serves as a starting point for creating a new Python + Dash application.
A comprehensive documentation can be found in the [wiki](<https://cds-adc-tfs.visualstudio.com/Civil%20Aero%20-%20Business%20and%20Regional%20(Deutschland)/_wiki/wikis/Civil%20Aero%20-%20Business%20and%20Regional%20(Deutschland).wiki?pagePath=%2FFerchau%20Documentation&pageId=3038&wikiVersion=GBwikiMaster>).

[![Build Status](https://cds-adc-tfs.visualstudio.com/Civil%20Aero%20-%20Business%20and%20Regional%20(Deutschland)/_apis/build/status/DataCentre-DashStarterProject?branchName=master)](https://cds-adc-tfs.visualstudio.com/Civil%20Aero%20-%20Business%20and%20Regional%20(Deutschland)/_build/latest?definitionId=342&branchName=master)

## How to get started?

1. Download the code from the repository
2. Create a virtual environment and install dependencies
3. Copy sample configuration files, add secrets and adjust to your needs.<br>
e.g. db_sample.json => db.json
4. Make sure your db user has the rights to create/modify the specified database
5. Execute `python run.py`
6. Checkout application structure in the wiki and make your own changes
7. For deployments you need to request a configuration entry for the Apache webserver - Therefore send a mail to Steve Green (DXC) containing the path to your wsgi script and tell him whether or not you need a specific virtual environment or the default python modules. Activating the virtual environment needs to be done in the wsgi file.


## What's in here?

- Configuration files for customizing the app
- Modular structure which helps organizing the code
- User Authentication using LDAP3 or Azure AD
- Database connections using SQL Alchemy
- Swagger API documentation
- Custom Logger
- Test setup with some api tests
- Linting/ Typing configuration
- Integration Tests
- CI configuration
- Bootstrap 4 and jQuery
- Login and User Page
- Online Monitor integration by providing a function and a decorator


## Tech Stack

- [Flask](https://github.com/pallets/flask) for providing the API and the dashboard
- [Dash](https://github.com/plotly/dash) for building the dashboard using Python
- [SQL Alchemy](<https://cds-adc-tfs.visualstudio.com/Civil%20Aero%20-%20Business%20and%20Regional%20(Deutschland)/_wiki/wikis/Civil%20Aero%20-%20Business%20and%20Regional%20(Deutschland).wiki?pagePath=%2FFerchau%20Documentation%2F8%20%252D%20Database%20Interaction&pageId=3063&wikiVersion=GBwikiMaster>) for database interactions
- [Flask-login + Flask-ldap3-login](<https://cds-adc-tfs.visualstudio.com/Civil%20Aero%20-%20Business%20and%20Regional%20(Deutschland)/_wiki/wikis/Civil%20Aero%20-%20Business%20and%20Regional%20(Deutschland).wiki?pagePath=%2FFerchau%20Documentation%2F7%20%252D%20User%20Authentication&pageId=3061&wikiVersion=GBwikiMaster>) for user authentication
- Full list in requirements.txt

## Contributors

- Sebastian Rehfeldt - Sebastian.Rehfeldt@ferchau.com

### Want to become a Contributor?

Every help or feedback is welcome! :)

1. Clone the code
2. Create a feature branch
3. Create a Pull Request once your feature is done
4. On successful review and automatic testing in the CI pipeline, the branch can be merged

### Code metrics

Running the CI pipeline can take a while when many parallel executions are triggered. You can help by running these commands and fixing all issues before creating the PR. You can copy them as they are into the integrated terminal of VS Code to run them in a batch.

Alternatively, you can execute all at once/ in parallel by starting the server and making a get request to localhost:4000/status . As of now, the status route includes no integration tests.

```bash
mypy .
flake8 .
python -m unittest discover -p "*_test.py"
pytest --webdriver Chrome src/dash_integration_tests/
del /f src\test.sqlite3
cd .. & pylint DataCentre-DashStarterProject --rcfile DataCentre-DashStarterProject/.pylintrc
```

Proxy note for windows: If you set HTTP_PROXY or HTTPS_PROXY environmental variables, the integration tests will fail.
